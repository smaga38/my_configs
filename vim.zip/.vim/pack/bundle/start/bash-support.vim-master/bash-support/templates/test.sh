#!/bin/bash - 
#===============================================================================
#
#          FILE: test.sh
# 
#         USAGE: ./test.sh 
# 
#   DESCRIPTION: 
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: SERGEI SMAGIN (), smagin@swemel.ru
#  ORGANIZATION: Technology Corporation 
#       CREATED: 09/18/2019 17:27
#      REVISION:  ---
#===============================================================================

set -o nounset                              # Treat unset variables as an error
